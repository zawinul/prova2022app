
function selectRole(userinfo, region, source) {

	
	return "tenant_a1_writer";
}

module.exports = {
	selectRole
};